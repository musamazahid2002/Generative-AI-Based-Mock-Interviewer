from app import create_app


def test_health():
    app = create_app()
    client = app.test_client()
    assert client.get('/api/health').status_code == 200


def test_chat_offline():
    app = create_app()
    client = app.test_client()
    res = client.post('/api/chat', json={'message': 'start interview', 'role': 'Developer'})
    assert res.status_code == 200
    assert 'reply' in res.get_json()
