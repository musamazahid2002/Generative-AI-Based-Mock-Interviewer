import json
import re
from typing import Any, Dict
from openai import OpenAI
from app.utils.schemas import InterviewRequest, InterviewResponse, ChatRequest, ChatResponse, ResumeRequest, ResumeResponse

INTERVIEW_SYSTEM = """You are a senior hiring manager and interview coach. Return only valid JSON with keys: score integer 0-10, feedback string, strengths array, improvements array, next_question string. Be specific, practical, and professional."""
CHAT_SYSTEM = """You are an AI mock interviewer inside a Flask app. Ask helpful interview questions, answer short guidance questions, and coach the candidate. Keep replies concise and practical."""
RESUME_SYSTEM = """You are an ATS resume reviewer. Return only valid JSON with keys: score integer 0-100, summary string, strengths array, improvements array."""

class AIService:
    def __init__(self, api_key: str = "", model: str = "gpt-4o-mini"):
        self.model = model
        self.client = OpenAI(api_key=api_key) if api_key else None

    def evaluate_answer(self, data: InterviewRequest) -> InterviewResponse:
        if not self.client:
            return self._offline_interview(data)
        try:
            content = self._chat_json(INTERVIEW_SYSTEM, f"Role: {data.role}\nTopic: {data.topic}\nQuestion: {data.question}\nAnswer: {data.answer}")
            return InterviewResponse(**content)
        except Exception:
            return self._offline_interview(data)

    def chat(self, data: ChatRequest) -> ChatResponse:
        if not self.client:
            return ChatResponse(reply=self._offline_chat(data.message, data.role))
        try:
            messages = [{"role": "system", "content": CHAT_SYSTEM}]
            for item in (data.history or [])[-8:]:
                messages.append({"role": item.role, "content": item.content})
            messages.append({"role": "user", "content": f"Target role: {data.role}\nMessage: {data.message}"})
            response = self.client.chat.completions.create(model=self.model, temperature=0.4, messages=messages)
            return ChatResponse(reply=(response.choices[0].message.content or "I am ready to continue the interview."))
        except Exception:
            return ChatResponse(reply=self._offline_chat(data.message, data.role))

    def analyze_resume(self, data: ResumeRequest) -> ResumeResponse:
        if not self.client:
            return self._offline_resume(data)
        try:
            content = self._chat_json(RESUME_SYSTEM, f"Target role: {data.target_role}\nResume:\n{data.resume_text}")
            return ResumeResponse(**content)
        except Exception:
            return self._offline_resume(data)

    def _chat_json(self, system: str, user: str) -> Dict[str, Any]:
        response = self.client.chat.completions.create(
            model=self.model,
            temperature=0.25,
            response_format={"type": "json_object"},
            messages=[{"role": "system", "content": system}, {"role": "user", "content": user}],
        )
        raw = response.choices[0].message.content or "{}"
        return json.loads(raw)

    def _offline_interview(self, data: InterviewRequest) -> InterviewResponse:
        words = re.findall(r"\w+", data.answer)
        has_example = any(x in data.answer.lower() for x in ["project", "built", "created", "improved", "managed", "%", "result"])
        score = min(10, max(4, 5 + (len(words) >= 35) + (len(words) >= 75) + has_example))
        return InterviewResponse(
            score=score,
            feedback="Good attempt. Use the STAR method: situation, task, action, and result. Add measurable outcomes and connect your answer to the target role.",
            strengths=["Clear intent", "Relevant answer"],
            improvements=["Add a concrete example", "Mention measurable results", "Keep the answer structured"],
            next_question=f"Describe a challenging {data.role} project and explain your exact contribution.",
        )

    def _offline_chat(self, message: str, role: str) -> str:
        text = message.lower()
        if "question" in text or "start" in text:
            return f"Let’s begin. For a {role} role: Tell me about a project you built, the problem it solved, and your measurable result."
        if "feedback" in text or "improve" in text:
            return "Improve by using STAR, adding numbers, naming the tools you used, and ending with what you learned."
        return "I can help you practice. Share your answer, ask for feedback, or type ‘start interview’ to get a role-based question."

    def _offline_resume(self, data: ResumeRequest) -> ResumeResponse:
        text = data.resume_text.lower()
        score = 55 + ("project" in text) * 10 + ("experience" in text) * 10 + ("python" in text or "flask" in text) * 10 + ("%" in text) * 10
        return ResumeResponse(
            score=min(score, 95),
            summary=f"Your resume has useful content for {data.target_role}, but it can be stronger with clearer achievements and role-specific keywords.",
            strengths=["Includes relevant experience", "Shows technical direction"],
            improvements=["Add measurable impact", "Use stronger action verbs", "Match keywords from the job description"],
        )
