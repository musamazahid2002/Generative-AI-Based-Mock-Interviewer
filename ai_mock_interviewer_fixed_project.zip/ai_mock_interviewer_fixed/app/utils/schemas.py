from typing import List, Optional
from pydantic import BaseModel, Field

class ChatMessage(BaseModel):
    role: str = Field(..., pattern="^(user|assistant)$")
    content: str = Field(..., min_length=1, max_length=3000)

class InterviewRequest(BaseModel):
    role: str = Field(default="Software Developer", min_length=2, max_length=80)
    topic: str = Field(default="General", max_length=80)
    question: str = Field(..., min_length=3, max_length=500)
    answer: str = Field(..., min_length=2, max_length=4000)
    history: Optional[List[ChatMessage]] = Field(default_factory=list)

class InterviewResponse(BaseModel):
    score: int = Field(..., ge=0, le=10)
    feedback: str
    strengths: List[str]
    improvements: List[str]
    next_question: str

class ChatRequest(BaseModel):
    message: str = Field(..., min_length=1, max_length=3000)
    role: str = Field(default="Software Developer", max_length=80)
    history: Optional[List[ChatMessage]] = Field(default_factory=list)

class ChatResponse(BaseModel):
    reply: str

class ResumeRequest(BaseModel):
    resume_text: str = Field(..., min_length=20, max_length=8000)
    target_role: str = Field(default="Software Developer", max_length=80)

class ResumeResponse(BaseModel):
    score: int = Field(..., ge=0, le=100)
    summary: str
    strengths: List[str]
    improvements: List[str]
