from flask import Blueprint, current_app, jsonify, request
from pydantic import ValidationError
from app.services.ai_service import AIService
from app.utils.schemas import InterviewRequest, ChatRequest, ResumeRequest

api_bp = Blueprint("api", __name__)

def service() -> AIService:
    return AIService(current_app.config.get("OPENAI_API_KEY", ""), current_app.config.get("OPENAI_MODEL", "gpt-4o-mini"))

def parse_json(schema):
    try:
        return schema(**(request.get_json(silent=True) or {})), None
    except ValidationError as exc:
        return None, ({"error": "Invalid input", "details": exc.errors()}, 400)

@api_bp.get("/health")
def health():
    return jsonify({"status": "ok"})

@api_bp.post("/interview/evaluate")
def evaluate_answer():
    payload, error = parse_json(InterviewRequest)
    if error:
        return jsonify(error[0]), error[1]
    return jsonify(service().evaluate_answer(payload).model_dump())

@api_bp.post("/chat")
def chat():
    payload, error = parse_json(ChatRequest)
    if error:
        return jsonify(error[0]), error[1]
    return jsonify(service().chat(payload).model_dump())

@api_bp.post("/resume/analyze")
def analyze_resume():
    payload, error = parse_json(ResumeRequest)
    if error:
        return jsonify(error[0]), error[1]
    return jsonify(service().analyze_resume(payload).model_dump())
