# AI Mock Interviewer - Fixed Professional Flask Project

## Features
- Dashboard
- Start Interview
- Question Bank
- Performance tracking using browser localStorage
- Resume Analyzer
- Working chatbot endpoint
- OpenAI support with safe offline fallback, so the app still works without an API key
- Clean Flask factory structure and scalable routes/services/utils folders

## Run
```bash
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
copy .env.example .env
python run.py
```

Open `http://127.0.0.1:5000`.

Add your OpenAI key inside `.env` for real AI responses. Without a key, the app uses offline demo responses.
